Console command: /admin-tool-teleport
Planet name: 
Вулкан:vulcanus
Наувис:nauvis
Глеба:gleba
Аквилло:aquilo
