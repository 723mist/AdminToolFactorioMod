-- Функция для разделения параметров с учётом кавычек
local function split_parameters(param)
local parts = {}
local current = ""
local in_quote = false
for c in param:gmatch(".") do
    if c == '"' then
        in_quote = not in_quote
        elseif c == ' ' and not in_quote then
            if current ~= "" then
                table.insert(parts, current)
                current = ""
                end
                else
                    current = current .. c
                    end
                    end
                    if current ~= "" then
                        table.insert(parts, current)
                        end
                        return parts
                        end

                        -- Регистрация команды
                        commands.add_command("admin-teleport-tool", {
                            description = "Телепортирует игрока на указанную поверхность. Использование: /admin-teleport-tool \"<игрок(его имя)>\" \"<название планеты(читать док)>\""},
                            function(command)
                            local admin = game.player
                            if not (admin and admin.admin) then
                                if admin then
                                    admin.print("Только админы могут использовать эту команду.")
                                    end
                                    return
                                    end

                                    if not command.parameter then
                                        admin.print("Использование: /admin-teleport-tool \"<игрок(его имя)>\" \"<название планеты(читать док)>\"")
                                        return
                                        end

                                        local params = split_parameters(command.parameter)
                                        if #params < 2 then
                                            admin.print("Недостаточно параметров. Используйте: /admin-teleport-tool \"<игрок>\" \"<поверхность>\"")
                                            return
                                            end

                                            local target_player_name = params[1]
                                            local surface_name = params[2]

                                            -- Поиск игрока
                                            local target_player = game.get_player(target_player_name)
                                            if not target_player or not target_player.connected then
                                                admin.print("Игрок '" .. target_player_name .. "' не найден или не в сети.")
                                                return
                                                end

                                                -- Проверка персонажа
                                                local character = target_player.character
                                                if not character then
                                                    admin.print("У игрока '" .. target_player_name .. "' нет персонажа.")
                                                    return
                                                    end

                                                    -- Поиск поверхности
                                                    local surface = game.get_surface(surface_name)
                                                    if not surface then
                                                        admin.print("Поверхность '" .. surface_name .. "' не найдена.")
                                                        return
                                                        end

                                                        -- Поиск безопасной позиции
                                                        local position = surface.find_non_colliding_position("character", {0, 0}, 100, 1)
                                                        if not position then
                                                            position = {0, 0}
                                                            end

                                                            -- Телепортация
                                                            character.teleport(position, surface)
                                                            admin.print("Игрок " .. target_player_name .. " телепортирован на поверхность " .. surface_name .. ".")
                                                            end)
