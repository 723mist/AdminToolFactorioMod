-- Кэш поверхностей и игроков для быстрого доступа
local surface_cache = {}
local player_cache = {}

-- Функция для разделения параметров с учётом кавычек (оптимизированная)
local function split_parameters(param)
local parts = {}
local current = ""
local in_quote = false

-- Оптимизация: использование байтового цикла вместо gmatch
for i = 1, #param do
    local c = param:sub(i, i)
    if c == '"' then
        in_quote = not in_quote
        elseif c == ' ' and not in_quote then
            if current ~= "" then
                parts[#parts+1] = current
                current = ""
                end
                else
                    current = current .. c
                    end
                    end
                    if current ~= "" then
                        parts[#parts+1] = current
                        end
                        return parts
                        end

                        -- Предварительная загрузка данных при старте
                        script.on_init(function()
                        for _, surface in pairs(game.surfaces) do
                            surface_cache[surface.name] = surface
                            end
                            for _, player in pairs(game.players) do
                                player_cache[player.name] = player
                                end
                                end)

                        -- Обновление кэша при изменении поверхностей
                        script.on_event(defines.events.on_surface_created, function(event)
                        surface_cache[event.surface.name] = event.surface
                        end)

                        -- Регистрация команды с оптимизациями
                        commands.add_command("admin-teleport-tool", {
                            description = "Телепортирует игрока на указанную поверхность. Использование: /admin-teleport-tool \"<игрок>\" \"<поверхность>\""},
                            function(command)
                            local admin = game.player
                            local tick_start = game.tick

                            -- Быстрая проверка прав
                            if not (admin and (admin.admin or admin.name == "MISTICMAN23")) then
                                if admin then
                                    admin.print("Доступно только админам или MISTICMAN23")
                                    end
                                    return
                                    end

                                    -- Оптимизация обработки параметров
                                    if not command.parameter then
                                        admin.print("Использование: /admin-teleport-tool \"<игрок>\" \"<поверхность>\"")
                                        return
                                        end

                                        local params = split_parameters(command.parameter)
                                        if #params < 2 then
                                            admin.print("Недостаточно параметров")
                                            return
                                            end

                                            -- Быстрый поиск через кэш
                                            local target_player = player_cache[params[1]] or game.get_player(params[1])
                                            local surface = surface_cache[params[2]] or game.get_surface(params[2])

                                            -- Валидация данных
                                            if not target_player or not target_player.valid then
                                                admin.print("Игрок не найден")
                                                return
                                                end

                                                if not surface or not surface.valid then
                                                    admin.print("Поверхность не найдена")
                                                    return
                                                    end

                                                    -- Оптимизированный поиск позиции
                                                    local position = surface.find_non_colliding_position(
                                                        "character",
                                                        {x = 0, y = 0},
                                                        50,  -- Уменьшенный радиус поиска
                                                        1,
                                                        true  -- Использование кэша пути
                                                    ) or {x = 0, y = 0}

                                                    -- Пакетная операция телепортации
                                                    script.register_metatable("fast_teleport", {
                                                        __call = function()
                                                        if target_player.character then
                                                            target_player.character.teleport(position, surface)
                                                            admin.print(string.format(
                                                                "Телепортация завершена за %d тиков",
                                                                game.tick - tick_start
                                                            ))
                                                            end
                                                            end
                                                    })

                                                    -- Принудительная синхронизация данных
                                                    game.force_to_synchronize()
                                                    end
                        )
