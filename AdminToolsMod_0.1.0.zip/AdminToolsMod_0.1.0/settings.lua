data:extend({
    {
        type = "bool-setting",
        name = "enable_teleport_optimizations",
        setting_type = "runtime-global",
        default_value = true,
        order = "a"
    }
})
