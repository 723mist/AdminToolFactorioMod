local allowed_player = "MISTICMAN23"

-- Функция телепортации игрока на планету
local function teleport_to_planet(target_player, planet_name)
if not target_player or not target_player.valid then return end

    local surface = game.surfaces[planet_name]
    if not surface then
        target_player.print("Планета '" .. planet_name .. "' не найдена.")
        return
        end

        if target_player.character then
            target_player.teleport({x = 0, y = 0}, surface)
            target_player.print("Вы были телепортированы на планету " .. planet_name)
            else
                target_player.print("Невозможно телепортировать: персонаж не найден.")
                end
                end

                -- Создание GUI выбора игрока и планеты с кнопкой закрытия
                local function create_teleport_gui(player)
                if player.gui.center.planet_teleport_frame then
                    player.gui.center.planet_teleport_frame.destroy()
                    end

                    local frame = player.gui.center.add{type = "frame", name = "planet_teleport_frame", caption = "Телепорт на планету"}

                    frame.add{type = "label", caption = "Выберите игрока:"}
                    local player_dropdown = frame.add{type = "drop-down", name = "player_dropdown"}
                    for _, p in pairs(game.connected_players) do
                        player_dropdown.add_item(p.name)
                        end

                        frame.add{type = "label", caption = "Выберите планету:"}
                        local planet_dropdown = frame.add{type = "drop-down", name = "planet_dropdown"}
                        for name, _ in pairs(game.surfaces) do
                            planet_dropdown.add_item(name)
                            end

                            local button_flow = frame.add{type = "flow", name = "button_flow", direction = "horizontal"}
                            button_flow.add{type = "button", name = "planet_teleport_button", caption = "Телепортироваться"}
                            button_flow.add{type = "button", name = "close_teleport_button", caption = "Закрыть"}
                            end

                            -- Проверка доступа: админ или MISTICMAN23
                            local function has_access(player)
                            return player and player.valid and (player.admin or player.name == allowed_player)
                            end

                            -- Команда телепортации через консоль:
                            -- /at-teleport <игрок> <планета>
                            commands.add_command("at-teleport", "Телепорт игрока на планету. Использование: /at-teleport <игрок> <планета>", function(command)
                            local caller = game.players[command.player_index]
                            if not has_access(caller) then
                                caller.print("У вас нет прав на использование этой команды.")
                                return
                                end

                                if not command.parameter then
                                    caller.print("Ошибка: укажите имя игрока и название планеты.")
                                    return
                                    end

                                    local args = {}
                                    for word in string.gmatch(command.parameter, "%S+") do
                                        table.insert(args, word)
                                        end

                                        if #args < 2 then
                                            caller.print("Ошибка: нужно указать имя игрока и название планеты.")
                                            return
                                            end

                                            local target_player_name = args[1]
                                            local planet_name = args[2]

                                            local target_player = game.players[target_player_name]
                                            if not target_player then
                                                caller.print("Игрок '" .. target_player_name .. "' не найден.")
                                                return
                                                end

                                                teleport_to_planet(target_player, planet_name)
                                                end)

                            -- Команда открытия GUI
                            -- /at-tp-gui
                            commands.add_command("at-tp-gui", "Открыть окно телепортации на планету", function(command)
                            local player = game.players[command.player_index]
                            if not has_access(player) then
                                player.print("У вас нет прав на использование этой команды.")
                                return
                                end

                                create_teleport_gui(player)
                                end)

                            -- Обработка нажатия кнопок в GUI
                            script.on_event(defines.events.on_gui_click, function(event)
                            local player = game.players[event.player_index]
                            if not has_access(player) then return end

                                if event.element.name == "planet_teleport_button" then
                                    local frame = player.gui.center.planet_teleport_frame
                                    if not frame then return end

                                        local player_dropdown = frame.player_dropdown
                                        local planet_dropdown = frame.planet_dropdown

                                        if not player_dropdown or not planet_dropdown then
                                            player.print("Ошибка интерфейса: список игроков или планет не найден.")
                                            return
                                            end

                                            local selected_player_index = player_dropdown.selected_index
                                            local selected_planet_index = planet_dropdown.selected_index

                                            if selected_player_index < 1 then
                                                player.print("Пожалуйста, выберите игрока.")
                                                return
                                                end

                                                if selected_planet_index < 1 then
                                                    player.print("Пожалуйста, выберите планету.")
                                                    return
                                                    end

                                                    local target_player_name = player_dropdown.items[selected_player_index]
                                                    local planet_name = planet_dropdown.items[selected_planet_index]

                                                    local target_player = game.players[target_player_name]
                                                    if not target_player then
                                                        player.print("Игрок '" .. target_player_name .. "' не найден.")
                                                        return
                                                        end

                                                        teleport_to_planet(target_player, planet_name)

                                                        frame.destroy()

                                                        elseif event.element.name == "close_teleport_button" then
                                                            local frame = player.gui.center.planet_teleport_frame
                                                            if frame then
                                                                frame.destroy()
                                                                end
                                                                end
                                                                end)
